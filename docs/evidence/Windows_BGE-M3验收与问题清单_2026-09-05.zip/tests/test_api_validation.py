"""Malformed public requests should fail validation before model execution."""
import pytest
from fastapi.testclient import TestClient
from api.server import app


@pytest.mark.parametrize('path', ['/short-term/validation_user', '/mid-term/validation_user'])
def test_invalid_layer_memory_type_is_validation_error(path):
    with TestClient(app) as client:
        assert client.get(path, params={'memory_type': 'invalid'}).status_code == 422


@pytest.mark.parametrize('extra', [
    {'memory_type': 'invalid'}, {'top_k': 0}, {'top_k': -1}, {'top_k': 101},
])
def test_invalid_recall_arguments_are_validation_errors(extra):
    with TestClient(app) as client:
        assert client.post('/recall', json={'user_id': 'validation_user', **extra}).status_code == 422
