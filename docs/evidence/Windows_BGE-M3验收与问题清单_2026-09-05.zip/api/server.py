"""REST API for OS Agent integration. Owner: 张官甜."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from src.common.models import MemoryType, RetrievalQuery
from src.core.factory import create_orchestrator
from src.core.orchestrator import MemoryOrchestrator, ProcessInputResult
from src.knowledge.memory_service.memory_schema import MemoryEntry

orchestrator: MemoryOrchestrator = create_orchestrator()

app = FastAPI(title="Kylin OS Agent Memory API", version="0.3.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class IngestRequest(BaseModel):
    user_id: str
    source: str
    payload: dict[str, Any] = Field(default_factory=dict)
    scene_id: str | None = None


class RecallRequest(BaseModel):
    user_id: str
    query: str = ""
    top_k: int = Field(default=5, ge=1, le=100)
    memory_type: MemoryType | None = None
    scene_id: str | None = None
    filters: dict[str, Any] = Field(default_factory=dict)


class StoreEntryRequest(BaseModel):
    entry: MemoryEntry


class ForgetRequest(BaseModel):
    user_id: str
    instruction: str


class PreferenceExtractRequest(BaseModel):
    user_id: str
    text: str
    scene_id: str | None = None
    source: str = "conversation"


class StagingPurgeRequest(BaseModel):
    raw_retention_days: int | None = Field(default=None, ge=0)
    audit_retention_days: int | None = Field(default=None, ge=0)


def _serialize_process_result(result: ProcessInputResult) -> dict[str, Any]:
    record = result.record.model_dump(mode="json") if result.record else None
    return {
        "accepted": result.accepted,
        "memory_id": result.memory_id,
        "memory_type": result.memory_type,
        "reject_code": result.reject_code,
        "reasons": result.reasons,
        "quality_score": result.quality_score,
        "fingerprint": result.fingerprint,
        "evicted_memory_id": result.evicted_memory_id,
        "updated_existing": result.updated_existing,
        "record": record,
    }


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


def _serialize_layer_snapshot(snapshot, *, role: str | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "count": snapshot.count,
        "capacity": snapshot.capacity,
        "preference_count": snapshot.preference_count,
        "knowledge_count": snapshot.knowledge_count,
    }
    if snapshot.avg_heat is not None:
        payload["avg_heat"] = snapshot.avg_heat
    if role is not None:
        payload["role"] = role
    return payload


@app.get("/stats/{user_id}")
def memory_stats(user_id: str) -> dict[str, Any]:
    stats = orchestrator.memory_stats(user_id)
    return {
        "user_id": stats.user_id,
        "total_count": stats.total_count,
        "total_preference_count": stats.total_preference_count,
        "total_knowledge_count": stats.total_knowledge_count,
        "layers": {
            "short": _serialize_layer_snapshot(stats.short),
            "mid": _serialize_layer_snapshot(stats.mid),
            "long": _serialize_layer_snapshot(stats.long, role="pending_persist"),
            "milvus": _serialize_layer_snapshot(stats.milvus, role="authoritative"),
        },
    }


@app.post("/ingest")
def ingest(req: IngestRequest) -> dict[str, Any]:
    result = orchestrator.process_input(
        req.payload,
        req.source,
        user_id=req.user_id,
        scene_id=req.scene_id,
    )
    body = _serialize_process_result(result)
    body["user_id"] = req.user_id
    body["status"] = "accepted" if result.accepted else "rejected"
    return body


@app.get("/short-term/{user_id}")
def list_short_term(
    user_id: str,
    limit: int = Query(default=10, ge=1, le=100),
    scene_id: str | None = None,
    memory_type: MemoryType | None = None,
) -> dict[str, Any]:
    parsed_type = MemoryType(memory_type) if memory_type is not None else None
    items = orchestrator.list_short_term(
        user_id,
        limit=limit,
        scene_id=scene_id,
        memory_type=parsed_type,
    )
    stats = orchestrator.short_term_stats(user_id)
    return {
        "user_id": user_id,
        "count": len(items),
        "capacity": stats.capacity,
        "preference_count": stats.preference_count,
        "knowledge_count": stats.knowledge_count,
        "items": [item.model_dump(mode="json") for item in items],
    }


@app.post("/short-term/{user_id}/{memory_id}/touch")
def touch_short_term(user_id: str, memory_id: str) -> dict[str, Any]:
    """记录记忆被 Agent 实际使用一次，为 short → mid 晋升提供热度信号。"""

    item = orchestrator.touch_short_term_item(user_id, memory_id)
    return {
        "user_id": user_id,
        "memory_id": memory_id,
        "touched": item is not None,
        "access_count": item.metadata.get("access_count") if item else None,
        "heat": item.metadata.get("heat") if item else None,
    }


@app.get("/mid-term/{user_id}")
def list_mid_term(
    user_id: str,
    limit: int = Query(default=20, ge=1, le=100),
    scene_id: str | None = None,
    memory_type: MemoryType | None = None,
) -> dict[str, Any]:
    parsed_type = MemoryType(memory_type) if memory_type is not None else None
    items = orchestrator.list_mid_term(
        user_id,
        limit=limit,
        scene_id=scene_id,
        memory_type=parsed_type,
    )
    stats = orchestrator.mid_term_stats(user_id)
    return {
        "user_id": user_id,
        "count": len(items),
        "capacity": stats.capacity,
        "preference_count": stats.preference_count,
        "knowledge_count": stats.knowledge_count,
        "avg_heat": stats.avg_heat,
        "items": [item.model_dump(mode="json") for item in items],
    }


@app.post("/consolidate/{user_id}/mid")
def consolidate_mid(user_id: str) -> dict[str, Any]:
    result = orchestrator.consolidate_mid(user_id)
    return {
        "user_id": result.user_id,
        "promoted_to_mid": result.promoted_to_mid,
        "short_remaining": result.short_remaining,
        "mid_remaining": result.mid_remaining,
    }


@app.post("/consolidate/{user_id}")
def consolidate(user_id: str) -> dict[str, Any]:
    result = orchestrator.consolidate(user_id)
    return {
        "user_id": result.user_id,
        "promoted_to_mid": result.promoted_to_mid,
        "promoted_to_long": result.promoted_to_long,
        "retained_in_mid": result.retained_in_mid,
        "short_remaining": result.short_remaining,
        "mid_remaining": result.mid_remaining,
        "stored_memory_ids": result.stored_memory_ids,
    }


@app.post("/store-entry")
def store_entry(req: StoreEntryRequest) -> dict[str, Any]:
    result = orchestrator.store_memory_entry(req.entry)
    return {
        "memory_id": result.memory_id,
        "created": result.created,
        "reason": result.reason,
        "superseded_memory_id": result.superseded_memory_id,
    }


@app.get("/preferences/{user_id}")
def list_preferences(
    user_id: str,
    preference_key: str | None = None,
    latest_only: bool = True,
    top_k: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    result = orchestrator.list_preferences(
        user_id,
        preference_key=preference_key,
        latest_only=latest_only,
        top_k=top_k,
    )
    return {
        "user_id": user_id,
        "count": len(result.items),
        "latency_ms": result.latency_ms,
        "items": [item.model_dump(mode="json") for item in result.items],
    }


@app.post("/preferences/extract")
def extract_preferences(req: PreferenceExtractRequest) -> dict[str, Any]:
    """从文本自动提取偏好并写入权威存储（含版本历史）。"""

    result = orchestrator.extract_preferences_from_text(
        req.text,
        user_id=req.user_id,
        scene_id=req.scene_id,
        source=req.source,
    )
    return {
        "user_id": result.user_id,
        "extracted_count": result.extracted_count,
        "mode": result.mode,
        "degraded_to_rules": result.degraded_to_rules,
        "entries": [entry.model_dump(mode="json") for entry in result.entries],
        "stored": [
            {
                "memory_id": item.memory_id,
                "created": item.created,
                "reason": item.reason,
                "superseded_memory_id": item.superseded_memory_id,
            }
            for item in result.stored
        ],
    }


@app.get("/preferences/{user_id}/profile")
def preference_profile(
    user_id: str,
    scene_id: str | None = None,
) -> dict[str, Any]:
    """结构化偏好画像（以权威长期存储为准）。"""

    profile = orchestrator.get_preference_profile(user_id, scene_id=scene_id)
    return {"user_id": user_id, "scene_id": scene_id, "profile": profile}


@app.get("/preferences/{user_id}/history")
def preference_history(
    user_id: str,
    preference_key: str = Query(..., min_length=1),
) -> dict[str, Any]:
    """权威长期存储版本链。"""

    items = orchestrator.get_preference_history(user_id, preference_key)
    return {
        "user_id": user_id,
        "preference_key": preference_key,
        "count": len(items),
        "items": [item.model_dump(mode="json") for item in items],
    }


@app.post("/recall")
def recall(req: RecallRequest) -> dict[str, Any]:
    parsed_type = MemoryType(req.memory_type) if req.memory_type is not None else None
    result = orchestrator.recall(
        RetrievalQuery(
            query=req.query,
            user_id=req.user_id,
            memory_type=parsed_type,
            scene_id=req.scene_id,
            top_k=req.top_k,
        ),
        filters=req.filters,
    )
    return {
        "user_id": req.user_id,
        "count": len(result.items),
        "latency_ms": result.latency_ms,
        "strategy": result.strategy,
        "items": [item.model_dump(mode="json") for item in result.items],
    }


@app.post("/forget")
def forget(req: ForgetRequest) -> dict[str, Any]:
    deleted_ids = orchestrator.forget(req.user_id, req.instruction)
    return {
        "user_id": req.user_id,
        "instruction": req.instruction,
        "count": len(deleted_ids),
        "deleted_ids": deleted_ids,
    }


@app.post("/staging/purge")
def purge_staging(req: StagingPurgeRequest) -> dict[str, Any]:
    """手动执行 ingestion raw/audit 保留期清理；自动调度后续再接。"""

    return orchestrator.purge_staging(
        raw_retention_days=req.raw_retention_days,
        audit_retention_days=req.audit_retention_days,
    )
