import { computed, createApp, nextTick, onMounted, ref, watch } from 'vue'
import './style.css'

const demoPreferences = [
  { id: 'pref-language-v2', key: 'response_language', value: '默认使用中文回答，并优先给出可执行步骤。', scene: 'coding', version: 2, active: true, confidence: 0.98 },
  { id: 'pref-language-v1', key: 'response_language', value: '使用中文进行回答。', scene: 'coding', version: 1, active: false, confidence: 0.91 },
  { id: 'pref-download', key: 'download_path', value: '下载文件默认保存到 D:/Downloads。', scene: 'os_operation', version: 1, active: true, confidence: 0.96 },
  { id: 'pref-code', key: 'programming_style', value: '代码示例偏好 Python，并添加必要注释。', scene: 'coding', version: 3, active: true, confidence: 0.94 },
]

const demoMemories = [
  { id: 'tool-024', type: 'knowledge', layer: 'long', content: 'pip 安装依赖超时：可使用清华镜像。', source: 'tool_result', scene: 'coding' },
  { id: 'doc-007', type: 'knowledge', layer: 'long', content: '麒麟系统缺少 pip 时，可先安装 python3-pip。', source: 'document', scene: 'os_operation' },
  { id: 'ctx-015', type: 'knowledge', layer: 'long', content: '项目后端使用 FastAPI 提供记忆摄取、检索、偏好及遗忘接口。', source: 'conversation', scene: 'coding' },
]

const demoStats = () => ({
  total_count: 18,
  total_preference_count: 6,
  total_knowledge_count: 12,
  layers: {
    short: { count: 3, capacity: 20 },
    mid: { count: 5, capacity: 50 },
    long: { count: 4 },
    milvus: { count: 6 },
  },
})

const initialMessages = [
  { id: 1, role: 'assistant', content: '你好，我是麒忆助理。你可以直接问我问题，也可以告诉我需要长期记住或遗忘的内容。', time: '刚刚' },
  { id: 2, role: 'user', content: '以后请用中文回答，并优先给出可以直接执行的步骤。', time: '刚刚' },
  { id: 3, role: 'assistant', content: '记住了。我会默认使用中文，并把可执行步骤放在前面。右侧已经同步生成的偏好记忆。', time: '刚刚' },
]

createApp({
  setup() {
    const user = ref('demo_user')
    const live = ref(false)
    const syncing = ref(false)
    const sending = ref(false)
    const modelSlow = ref(false)
    const activeTab = ref('overview')
    const draft = ref('')
    const messages = ref([...initialMessages])
    const memories = ref([...demoMemories])
    const preferences = ref([...demoPreferences])
    const profile = ref({ features: [] })
    const stats = ref(demoStats())
    const latency = ref('演示数据')
    const lastSynced = ref('尚未连接')
    const events = ref([
      { id: 1, type: 'preference', title: '识别到回答偏好', detail: 'response_language · v2', time: '刚刚' },
      { id: 2, type: 'memory', title: '沉淀项目上下文', detail: 'conversation · long', time: '2 分钟前' },
    ])
    const forgetInstruction = ref('')
    const forgetResult = ref('等待遗忘指令…')
    const toast = ref('')
    const chatScroll = ref(null)

    const tabs = [
      ['overview', '总览'],
      ['preferences', '偏好'],
      ['memories', '记忆'],
      ['forget', '遗忘'],
    ]

    const activePreferences = computed(() => {
      const features = profile.value?.features || []
      if (features.length) {
        return features.map((item) => ({
          id: item.feature_id || item.preference_key,
          key: item.preference_key,
          value: item.value,
          scene: item.scene_id || item.scope || 'global',
          version: item.version || 1,
          active: true,
          confidence: item.confidence ?? 0,
        }))
      }
      return preferences.value.filter((item) => item.active)
    })

    const statusText = computed(() => live.value ? '实时 API 已连接' : '演示数据模式')

    const tell = (message) => {
      toast.value = message
      window.clearTimeout(tell.timer)
      tell.timer = window.setTimeout(() => { toast.value = '' }, 2600)
    }

    const fetchWithTimeout = async (path, options = {}, timeout = 180000) => {
      const controller = new AbortController()
      const timer = window.setTimeout(() => controller.abort(), timeout)
      try {
        const response = await fetch(`/api${path}`, {
          headers: { 'Content-Type': 'application/json' },
          ...options,
          signal: controller.signal,
        })
        if (!response.ok) {
          let detail = ''
          try { detail = (await response.json()).detail || '' } catch {}
          throw new Error(detail || `请求失败 (${response.status})`)
        }
        return await response.json()
      } catch (error) {
        if (error.name === 'AbortError') throw new Error('请求超时，模型可能仍在初始化')
        throw error
      } finally {
        window.clearTimeout(timer)
      }
    }

    const call = (path, options, timeout) => {
      if (!live.value) throw new Error('当前为演示数据模式')
      return fetchWithTimeout(path, options, timeout)
    }

    const mapPreference = (item) => ({
      id: item.id ?? item.memory_id,
      key: item.metadata?.preference_key || '未命名偏好',
      value: item.metadata?.preference_value ?? item.content,
      scene: item.scene_id || item.metadata?.task_type || 'global',
      version: item.version ?? item.metadata?.version ?? 1,
      active: item.metadata?.is_latest ?? true,
      confidence: item.metadata?.confidence ?? item.confidence ?? 0,
    })

    const mapMemory = (item) => ({
      id: item.id ?? item.memory_id,
      type: item.memory_type || 'knowledge',
      layer: item.layer || 'long',
      content: item.content,
      source: item.metadata?.source || item.metadata?.source_type,
      scene: item.scene_id || item.metadata?.task_type,
    })

    const now = () => new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit' }).format(new Date())

    // Clear user-specific and demo content before displaying a live session.
    const clearLiveSession = () => {
      memories.value = []
      preferences.value = []
      profile.value = { features: [] }
      stats.value = {
        total_count: 0, total_preference_count: 0, total_knowledge_count: 0,
        layers: { short: { count: 0 }, mid: { count: 0 }, long: { count: 0 }, milvus: { count: 0 } },
      }
      messages.value = [{ ...initialMessages[0] }]
      events.value = []
      latency.value = '尚未检索'
      lastSynced.value = '尚未同步'
      forgetInstruction.value = ''
      forgetResult.value = '等待遗忘指令…'
    }

    const pushEvent = (type, title, detail) => {
      events.value.unshift({ id: Date.now() + Math.random(), type, title, detail, time: now() })
      events.value = events.value.slice(0, 12)
    }

    const scrollToBottom = async () => {
      await nextTick()
      if (chatScroll.value) chatScroll.value.scrollTop = chatScroll.value.scrollHeight
    }

    const loadDashboard = async ({ quiet = false } = {}) => {
      if (!live.value) return
      syncing.value = true
      const encodedUser = encodeURIComponent(user.value)
      const [statsResult, historyResult, profileResult] = await Promise.allSettled([
        call(`/stats/${encodedUser}`, {}, 30000),
        call(`/preferences/${encodedUser}?latest_only=false&top_k=100`, {}, 180000),
        call(`/preferences/${encodedUser}/profile`, {}, 30000),
      ])
      if (encodedUser !== encodeURIComponent(user.value) || !live.value) return
      if (statsResult.status === 'fulfilled') stats.value = statsResult.value
      if (historyResult.status === 'fulfilled') preferences.value = historyResult.value.items.map(mapPreference).sort((a, b) => b.version - a.version)
      if (profileResult.status === 'fulfilled') profile.value = profileResult.value.profile
      lastSynced.value = now()
      syncing.value = false
      if (!quiet) {
        const failed = [statsResult, historyResult, profileResult].filter((item) => item.status === 'rejected').length
        tell(failed ? `数据已刷新，${failed} 项接口暂时不可用` : '记忆面板已同步')
      }
    }

    const connect = async ({ quiet = false } = {}) => {
      if (live.value && !quiet) {
        live.value = false
        stats.value = demoStats()
        preferences.value = [...demoPreferences]
        profile.value = { features: [] }
        memories.value = [...demoMemories]
        lastSynced.value = '尚未连接'
        tell('已切换为演示数据模式')
        return
      }
      syncing.value = true
      try {
        await fetchWithTimeout('/health', {}, quiet ? 3500 : 10000)
        clearLiveSession()
        live.value = true
        await loadDashboard({ quiet: true })
        if (!quiet) tell('已连接本地 API')
      } catch (error) {
        live.value = false
        if (!quiet) tell(`连接失败：${error.message}`)
      } finally {
        syncing.value = false
      }
    }

    const buildAssistantReply = (items, saved) => {
      if (!items.length) return saved
        ? '暂时没有检索到相关长期记忆。本轮内容已写入记忆，后续可以继续补充。'
        : '暂时没有检索到相关长期记忆。本轮内容未写入记忆，请查看右侧处理结果。'
      const facts = items.slice(0, 3).map((item, index) => `${index + 1}. ${item.content}`).join('\n')
      return `我从记忆中找到了 ${items.length} 条相关信息：\n\n${facts}\n\n右侧“记忆”页可以查看来源和记忆编号。`
    }

    const sendMessage = async () => {
      const text = draft.value.trim()
      if (!text || sending.value) return
      messages.value.push({ id: Date.now(), role: 'user', content: text, time: now() })
      draft.value = ''
      sending.value = true
      modelSlow.value = false
      await scrollToBottom()

      if (!live.value) {
        await new Promise((resolve) => window.setTimeout(resolve, 350))
        const reply = text.includes('忘')
          ? '你可以在右侧打开“遗忘”，确认需要删除的范围。演示模式不会伪造删除成功。'
          : '我会结合已保存的偏好和记忆来回答。当前是演示模式，连接本地 API 后将显示真实召回与写入结果。'
        messages.value.push({ id: Date.now() + 1, role: 'assistant', content: reply, time: now() })
        pushEvent('conversation', '完成一轮演示对话', '连接 API 后将实时写入')
        sending.value = false
        await scrollToBottom()
        return
      }

      const slowTimer = window.setTimeout(() => { modelSlow.value = true }, 2500)
      const [recallResult, ingestResult] = await Promise.allSettled([
        call('/recall', { method: 'POST', body: JSON.stringify({ user_id: user.value, query: text, top_k: 5 }) }, 180000),
        call('/ingest', { method: 'POST', body: JSON.stringify({ user_id: user.value, source: 'conversation', payload: { content: text } }) }, 180000),
      ])
      window.clearTimeout(slowTimer)

      if (recallResult.status === 'fulfilled') {
        memories.value = recallResult.value.items.map(mapMemory)
        latency.value = `${Math.round(recallResult.value.latency_ms)} ms`
        messages.value.push({ id: Date.now() + 1, role: 'assistant', content: buildAssistantReply(memories.value, ingestResult.status === 'fulfilled' && ingestResult.value.accepted), time: now() })
        pushEvent('recall', '完成记忆召回', `${memories.value.length} 条 · ${latency.value}`)
      } else {
        messages.value.push({ id: Date.now() + 1, role: 'assistant', content: `记忆检索暂时失败：${recallResult.reason.message}`, time: now() })
        pushEvent('error', '记忆召回失败', recallResult.reason.message)
      }

      if (ingestResult.status === 'fulfilled') {
        const result = ingestResult.value
        if (result.accepted) {
          pushEvent(result.updated_existing ? 'preference' : 'memory', result.updated_existing ? '更新了已有记忆' : '写入了新记忆', result.memory_id || '后端未返回 ID')
        } else {
          pushEvent('error', '本次内容未写入记忆', result.reasons?.join('；') || result.reject_code || '未通过质量校验')
        }
      } else {
        pushEvent('error', '对话写入失败', ingestResult.reason.message)
      }

      await loadDashboard({ quiet: true })
      sending.value = false
      modelSlow.value = false
      await scrollToBottom()
    }

    const handleComposerKeydown = (event) => {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault()
        sendMessage()
      }
    }

    const usePrompt = (prompt) => {
      draft.value = prompt
      nextTick(() => document.querySelector('.chat-composer textarea')?.focus())
    }

    const prepareForget = (item, kind = 'memory') => {
      forgetInstruction.value = kind === 'preference' ? `忘掉关于 ${item.key} 的偏好` : `忘掉记忆 ${item.id}`
      activeTab.value = 'forget'
    }

    const forget = async () => {
      const instruction = forgetInstruction.value.trim()
      if (!instruction) return tell('请先输入需要遗忘的内容')
      if (!live.value) {
        forgetResult.value = `演示模式不会模拟删除成功。\n连接 API 后将发送：${instruction}`
        return tell('请先连接本地 API')
      }
      syncing.value = true
      try {
        const result = await call('/forget', { method: 'POST', body: JSON.stringify({ user_id: user.value, instruction }) }, 180000)
        forgetResult.value = `已处理：${result.instruction}\n删除数量：${result.count}\n删除 ID：${result.deleted_ids.length ? result.deleted_ids.join(', ') : '无'}`
        const deleted = new Set(result.deleted_ids)
        memories.value = memories.value.filter((item) => !deleted.has(item.id))
        pushEvent('forget', '执行安全遗忘', `${result.count} 条记忆已删除`)
        await loadDashboard({ quiet: true })
        tell('遗忘结果已同步')
      } catch (error) {
        forgetResult.value = `遗忘失败：${error.message}`
        pushEvent('error', '安全遗忘失败', error.message)
        tell('遗忘请求失败')
      } finally {
        syncing.value = false
      }
    }

    let userRefreshTimer
    watch(user, () => {
      window.clearTimeout(userRefreshTimer)
      if (live.value) {
        clearLiveSession()
        userRefreshTimer = window.setTimeout(() => loadDashboard({ quiet: true }), 500)
      }
    })

    onMounted(() => {
      scrollToBottom()
      connect({ quiet: true })
    })

    return { user, live, syncing, sending, modelSlow, activeTab, draft, messages, memories, preferences, stats, latency, lastSynced, events, forgetInstruction, forgetResult, toast, chatScroll, tabs, activePreferences, statusText, connect, loadDashboard, sendMessage, handleComposerKeydown, usePrompt, prepareForget, forget }
  },
  template: `
    <div class="app-shell">
      <header class="topbar">
        <div class="brand-mark"><span>◇</span><div><b>麒忆智脑</b><small>OS Agent Memory</small></div></div>
        <div class="top-actions">
          <label>用户 <input v-model="user" aria-label="用户 ID" :disabled="sending || syncing" /></label>
          <button class="sync-button" :disabled="syncing" @click="loadDashboard()">{{ syncing ? '同步中…' : '↻ 同步' }}</button>
          <button class="connection-button" :class="{ live }" :disabled="sending || syncing" @click="connect()"><i></i>{{ statusText }}</button>
        </div>
      </header>

      <main class="dual-layout">
        <section class="chat-panel">
          <div class="panel-heading">
            <div><span class="eyebrow">MEMORY ASSISTANT</span><h1>和麒忆助理对话</h1><p>对话会参与记忆召回，并在右侧实时形成偏好与记忆记录。</p></div>
            <div class="assistant-avatar">麒</div>
          </div>
          <div class="chat-stream" ref="chatScroll">
            <div class="message-row" v-for="message in messages" :key="message.id" :class="message.role">
              <div class="avatar">{{ message.role === 'assistant' ? '麒' : 'Z' }}</div>
              <div class="message-wrap">
                <div class="message-meta"><b>{{ message.role === 'assistant' ? '麒忆助理' : '你' }}</b><span>{{ message.time }}</span></div>
                <div class="bubble">{{ message.content }}</div>
              </div>
            </div>
            <div class="message-row assistant" v-if="sending">
              <div class="avatar">麒</div><div class="message-wrap"><div class="message-meta"><b>麒忆助理</b><span>处理中</span></div><div class="bubble thinking"><i></i><i></i><i></i><span>{{ modelSlow ? '模型初始化中，首次加载 BGE-M3 可能较慢…' : '正在检索并写入记忆…' }}</span></div></div>
            </div>
          </div>
          <div class="prompt-chips">
            <button @click="usePrompt('根据我的偏好，给出一个 Python 项目搭建方案')">项目搭建建议</button>
            <button @click="usePrompt('你记得我的哪些使用习惯？')">查看我的习惯</button>
            <button @click="usePrompt('以后回答请更加简洁')">新增回答偏好</button>
          </div>
          <form class="chat-composer" @submit.prevent="sendMessage">
            <textarea v-model="draft" @keydown="handleComposerKeydown" placeholder="输入问题，或告诉我需要记住的内容…" aria-label="对话输入"></textarea>
            <div><span>Enter 发送 · Shift + Enter 换行</span><button :disabled="!draft.trim() || sending">{{ sending ? '处理中' : '发送 ↑' }}</button></div>
          </form>
        </section>

        <aside class="memory-panel">
          <div class="memory-header">
            <div><span class="eyebrow">LIVE MEMORY</span><h2>实时记忆面板</h2></div>
            <div class="live-state"><i :class="{ live }"></i><span>{{ live ? '实时同步' : '演示模式' }}<small>上次同步 {{ lastSynced }}</small></span></div>
          </div>
          <nav class="memory-tabs" aria-label="记忆面板导航">
            <button v-for="tab in tabs" :key="tab[0]" :class="{ active: activeTab === tab[0] }" @click="activeTab = tab[0]">{{ tab[1] }}</button>
          </nav>
          <div class="memory-content">
            <template v-if="activeTab === 'overview'">
              <div class="stat-grid"><div><span>总记忆</span><b>{{ stats.total_count }}</b><small>跨层统一视图</small></div><div><span>偏好记忆</span><b>{{ stats.total_preference_count }}</b><small>版本可追溯</small></div><div><span>知识记忆</span><b>{{ stats.total_knowledge_count }}</b><small>可供语义召回</small></div></div>
              <section class="side-section"><div class="section-title"><h3>记忆分层</h3><span>{{ live ? '来自 /stats' : '演示数据' }}</span></div><div class="layer-row"><span>短期记忆</span><div><i :style="{ width: Math.min(100, stats.layers.short.count / (stats.layers.short.capacity || 20) * 100) + '%' }"></i></div><b>{{ stats.layers.short.count }} / {{ stats.layers.short.capacity || '∞' }}</b></div><div class="layer-row"><span>中期记忆</span><div><i :style="{ width: Math.min(100, stats.layers.mid.count / (stats.layers.mid.capacity || 50) * 100) + '%' }"></i></div><b>{{ stats.layers.mid.count }} / {{ stats.layers.mid.capacity || '∞' }}</b></div><div class="layer-row"><span>长期待入库</span><div><i :style="{ width: Math.min(100, stats.layers.long.count * 10) + '%' }"></i></div><b>{{ stats.layers.long.count }}</b></div><div class="layer-row"><span>知识库</span><div><i :style="{ width: Math.min(100, stats.layers.milvus.count * 8) + '%' }"></i></div><b>{{ stats.layers.milvus.count }}</b></div></section>
              <section class="side-section"><div class="section-title"><h3>最近活动</h3><span>自动刷新</span></div><div class="event-item" v-for="event in events" :key="event.id"><i :class="event.type">{{ event.type === 'forget' ? '⌫' : event.type === 'preference' ? '◌' : event.type === 'error' ? '!' : '◇' }}</i><span><b>{{ event.title }}</b><small>{{ event.detail }}</small></span><time>{{ event.time }}</time></div></section>
            </template>
            <template v-else-if="activeTab === 'preferences'">
              <div class="section-title sticky-title"><h3>当前生效偏好</h3><span>{{ activePreferences.length }} 项</span></div><div class="empty-state" v-if="!activePreferences.length">当前用户还没有生效偏好</div><article class="preference-card" v-for="item in activePreferences" :key="item.id || item.key"><div><code>{{ item.key }}</code><span>v{{ item.version }}</span></div><p>{{ item.value }}</p><footer><small>{{ item.scene }} · 置信度 {{ Math.round((item.confidence || 0) * 100) }}%</small><button @click="prepareForget(item, 'preference')">准备遗忘</button></footer></article><div class="section-title history-title"><h3>版本历史</h3><span>{{ preferences.length }} 条</span></div><div class="history-item" v-for="item in preferences" :key="(item.id || item.key) + '-' + item.version"><b>v{{ item.version }}</b><span><strong>{{ item.key }}</strong><small>{{ item.active ? '当前版本' : '已被替换' }} · {{ item.value }}</small></span></div>
            </template>
            <template v-else-if="activeTab === 'memories'">
              <div class="section-title sticky-title"><h3>本轮召回记忆</h3><span>{{ latency }} · {{ memories.length }} 条</span></div><div class="empty-state" v-if="!memories.length">发送一条消息后，这里会显示真实召回结果</div><article class="memory-card" v-for="item in memories" :key="item.id"><div><code>{{ item.type }}</code><span>{{ item.layer }}</span><small>{{ item.id }}</small></div><p>{{ item.content }}</p><footer><span>{{ item.scene || '通用场景' }} · {{ item.source || '未知来源' }}</span><button @click="prepareForget(item)">准备遗忘</button></footer></article>
            </template>
            <template v-else>
              <div class="forget-intro"><span>SECURE FORGETTING</span><h3>安全遗忘</h3><p>用自然语言描述需要删除的记忆。只有后端真实删除成功后，右侧数据才会更新。</p></div><textarea class="forget-input" v-model="forgetInstruction" placeholder="例如：忘掉关于 Java 的偏好"></textarea><button class="danger-button" :disabled="syncing" @click="forget">{{ syncing ? '处理中…' : '执行遗忘' }}</button><pre class="forget-result">{{ forgetResult }}</pre><div class="safety-note"><b>隐私提示</b><span>敏感信息由后端安全模块解析和清理；前端不会伪造成功结果。</span></div>
            </template>
          </div>
        </aside>
      </main>
      <Transition><div class="toast" v-if="toast">{{ toast }}</div></Transition>
    </div>
  `,
}).mount('#app')
